package com.company;

import java.util.Stack;

public class Q85 {
    public int maximalRectangle(char[][] matrix) {
        
        return 0;
    }
    public int largestRectangleArea(int[] heights) {
        int max=0;
        int[] ps = prevSmaller(heights);
        int[] ns = nextSmaller(heights);
        for (int i=0;i<heights.length;i++)
        {
            int curr = (ns[i]-ps[i]-1) * heights[i];
            max = Math.max(max,curr);
        }
        return max;
    }

    private int[] nextSmaller(int[] heights) {
        int[] ns = new int[heights.length];
        Stack<Integer> s = new Stack<>();
        for (int i=heights.length-1;i>=0;i--)
        {
            while(!s.isEmpty() && heights[s.peek()] >= heights[i] ) s.pop();
            if (s.isEmpty()) ns[i] = heights.length;
            else ns[i] = s.peek();
            s.push(i);
        }

        return ns;
    }

    private int[] prevSmaller(int[] heights) {
        int[] ps = new int[heights.length];
        Stack<Integer> s = new Stack<>();
        for (int i=0;i<heights.length;i++)
        {
            while(!s.isEmpty() && heights[s.peek()] >= heights[i] ) s.pop();
            if (s.isEmpty()) ps[i] = -1;
            else ps[i] = s.peek();
            s.push(i);
        }
        return ps;
    }
    public static void main(String[] args) {
        char[][] matrix = {{'1','0','1','0','0'},{'1','0','1','1','1'},
                {'1','1','1','1','1'},{'1','0','0','1','0'}};
        System.out.println(new Q85().maximalRectangle(matrix));
    }
}
