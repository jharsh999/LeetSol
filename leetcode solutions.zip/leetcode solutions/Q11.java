package com.company;

public class Q11 {
    public int maxArea(int[] height) {
        int max = 0,first=0,last=height.length-1;
        while(first<last)
        {
            max = Math.max(max,Math.min(height[first],height[last]) * (last-first));
            if (height[first]<height[last]) first++;
            else last--;
        }
        return max;
    }
    public static void main(String[] args) {
        int[] height = {1, 5, 4, 3};
        System.out.println(new Q11().maxArea(height));
    }
}
