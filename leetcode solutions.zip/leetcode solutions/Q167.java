package com.company;

public class Q167 {
    public int[] twoSum(int[] numbers, int target) {
        int left=0,right= numbers.length-1;
        while(left!=right)
        {
            if(numbers[left]+numbers[right]==target) return new int[]{left+1,right+1};
            else if(numbers[left]+numbers[right]<target) left++;
            else if(numbers[left]+numbers[right]>target) right--;
        }
        return new int[]{-1,-1};
    }
    public static void main(String[] args) {
        int[] numbers = {2,7,11,15};
        int[] res = new int[2];
        for (int i : res)
        {
            System.out.println(i);
        }
    }
}
