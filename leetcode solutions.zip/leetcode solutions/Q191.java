package com.company;

public class Q191 {
    public int hammingWeight(int n) {
        return n;
    }
    public static void main(String[] args) {
        int n = 00000000000000000000000000001011;
        System.out.println(n);

    }
}
