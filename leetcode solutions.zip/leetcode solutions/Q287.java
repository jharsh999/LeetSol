package com.company;

import java.util.Arrays;

public class Q287 {
    public int findDuplicate(int[] nums) {
        int slow = 0;
        int fast = 0;

        do{
            System.out.println(nums[slow]);
            slow = nums[slow];
            System.out.println(nums[nums[fast]]);
            fast = nums[nums[fast]];
        } while(slow != fast);

        int find = 0;

        while(find != slow){
            slow = nums[slow];
            find = nums[find];
        }
        return find;
    }
    public static void main(String[] args) {
        int[] nums = {3,1,3,4,2};
        System.out.println(new Q287().findDuplicate(nums));
    }
}
