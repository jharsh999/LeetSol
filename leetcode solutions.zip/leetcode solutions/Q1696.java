package com.company;

public class Q1696 {
    public int maxResult(int[] nums, int k) {
        int max=0,maxSofar=nums[0];
        int i=0,j;
        while (i<nums.length)
        {
            for (j=i;j<k;j++)
            {
                if (nums[j]>maxSofar)
                {
                    maxSofar=nums[j];
                    i=j;
                }
            }
            max+=maxSofar;
        }
        return max;
    }
    public static void main(String[] args) {
        int[] nums = {1,-1,-2,4,-7,3};
        System.out.println(new Q1696().maxResult(nums,2));
    }
}
