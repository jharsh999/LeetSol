package com.company;

public class Q122 {
    public int maxProfit(int[] prices) {
        int maxPro=0;
        for (int i=1 ; i<prices.length ; i++)
        {
            if (prices[i]>prices[i-1])
            {
                maxPro += prices[i] - prices[i-1];
            }
        }
        return maxPro;
    }
    public static void main(String[] args) {
        int [] prices = {7,1,5,3,6,4};
        Q122 q = new Q122();
        System.out.println(q.maxProfit(prices));
    }
}
