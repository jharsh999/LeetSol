package com.company;

public class Q704 {
    public int search(int[] nums,int target)
    {
        return recBin(nums,target,0,nums.length-1);
    }
    public int recBin(int[] nums,int target,int l,int h)
    {
        if (l>h) return -1;
        int mid = l + (h-l)/2;
        if (nums[mid]==target) return mid;
        if (nums[mid]>target) return recBin(nums,target,l,mid-1);
        else return recBin(nums,target,mid+1,h);
    }
    public static void main(String[] args) {
        int[] nums = {-1,0,3,5,9,12};
        System.out.println(new Q704().search(nums,9));
    }
}
//    public int search(int[] nums, int target) {
//        int l=0,h= nums.length-1;
//        int mid=0;
//
//        while(l<=h)
//        {
//            mid=l+(h-l)/2;
//            if (nums[mid]==target) return mid;
//            if(nums[mid]>target)
//            {
//                h=mid-1;
//            }
//            else
//            {
//                l=mid+1;
//            }
//        }
//        return -1;
//    }