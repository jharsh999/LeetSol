package com.company;

import java.util.ArrayList;
import java.util.Arrays;

public class Q242 {
    public boolean isAnagram(String s, String t) {
        if(s.length()!=t.length()) return false;

        int[] arr = new int[26];
        for(int i=0; i<s.length(); i++){
            arr[s.charAt(i)-'a']++;
            arr[t.charAt(i)-'a']--;
        }

        for(int i: arr){
            if(i!=0)
                return false;
        }

        return true;
    }
    public static void main(String[] args) {
        String s = "anaram", t = "naaram";
        System.out.println(new Q242().isAnagram(s,t));
    }
}
