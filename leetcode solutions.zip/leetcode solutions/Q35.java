package com.company;

public class Q35 {
    public int binarySearch(int[] nums, int target) {
        int first = 0 , last = nums.length-1 , index=-1;
        int mid = first + (last - first) / 2;
        while (first <= last) {

            if (nums[mid] < target) {

                first = mid + 1;
                index = mid + 1;
            }
            else if (nums[mid] == target) {

               return mid;
            }
            else {
                index = mid;
                last = mid - 1;
            }
            mid = (first + last) / 2;
        }
            return index;
    }

        public static void main(String[] args)
        {
            Q35 q2 = new Q35();
            int[] arr1 = {1,3,5,6};
            int key1 = 0;
            int last1 = arr1.length - 1;
            System.out.println(q2.binarySearch(arr1, key1));
        }
    }




