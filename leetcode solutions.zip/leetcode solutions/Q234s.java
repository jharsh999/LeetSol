package com.company;

public class Q234s {
    class listNode
    {
        int value;
        listNode next;
        listNode(int x)
        {
            value = x;
            next = null;
        }
    }
        static listNode front;
        static boolean palindromeCheck(listNode head)
        {
            if(head == null)
                return true;
            if(!palindromeCheck(head.next))
                return false;
            if(front.value != head.value)
                return false;
            front = front.next;
            return true;
        }
        static boolean isPalindrome(listNode head)
        {
            front = head;
            return palindromeCheck(head);
        }

    public static void main(String[] args) {
//        Q234s q = new Q234s();
//        ListNode n1 = q.new
//        ListNode n2= q.new ListNode(2);
//        ListNode n3 = q.new ListNode(2);
//      ListNode n4= q.new ListNode(3);
//      ListNode n5 = q.new ListNode(1);
//      ListNode n6 = q.new ListNode(2);
//      ListNode n7= q.new ListNode(3);
//      ListNode n8 = q.new ListNode(1);
//
//        ListNode head = n1;
//        head.next = null;
//      n2.next = null;
//      n3.next = n4;
//      n4.next = n5;
//      n5.next = n6;
//      n6.next = n7;
//      n7.next = n8;
//      n8.next = null;
//        System.out.println(q.isPalindrome(head));
    }

}
