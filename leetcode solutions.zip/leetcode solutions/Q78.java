package com.company;

import java.util.ArrayList;
import java.util.List;

public class Q78 {
    public List<List<Integer>> subsets(int[] nums) {
        List<List<Integer>> ans = new ArrayList();
        ans.add(new ArrayList<>());
        for (int num:nums)
        {
            int n = ans.size();
            for (int i=0;i<n;i++)
            {
                List<Integer> temp = new ArrayList<>(ans.get(i));
                temp.add(num);
                ans.add(temp);
            }
        }
        return ans;
    }
    public static void main(String[] args) {
        int[] nums = {1,2,3};
        List<List<Integer>> ans = new Q78().subsets(nums);
        for(List l : ans)
        {
            System.out.println(l);
        }
    }
}
