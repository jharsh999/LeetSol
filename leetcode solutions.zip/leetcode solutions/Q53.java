package com.company;

public class Q53 {
    public int maxSubArray(int[] nums) {
        int currsum=0,maxsum=Integer.MIN_VALUE;
        for(int i=0;i< nums.length;i++){
            currsum= currsum + nums[i];
            if(currsum>maxsum)
                maxsum=currsum;
            if(currsum<0)
                currsum=0;
        }
        return maxsum;
    }
    public static void main(String[] args) {
        int[] nums={-2,-1,-3,-4,-1,-2,-1,-5,-4};
        Q53 q1 = new Q53();
        System.out.println(q1.maxSubArray(nums));
    }
}

/*
int currsum=0,maxsum=INT_MIN;
        for(int i=0;i<n;i++){
            currsum= currsum + arr[i];
            if(currsum>maxsum)
            maxsum=currsum;
            if(currsum<0)
            currsum=0;
        }
        return maxsum;
 */

/*
public class MaxSubArrayCalc {
@Getter
int sum =Integer.MIN_VALUE;
Map<Integer, Integer> map = new HashMap<>();
    public void calcMaxSubArraySum(int[] arr) {

         calcMaxSubArraySum(arr,  arr.length);
    }

    private int calcMaxSubArraySum(int[] arr, int n) {

        if(n==0 )
            return 0;
        if(map.containsKey(n))
            return map.get(n);
        int val = Math.max(arr[n - 1], (calcMaxSubArraySum(arr, n - 1) + arr[n - 1]));

        sum = Math.max(val, sum);
         map.put(n, val);
         return val;

    }
}
 */

/*
int maxSubArray(vector<int>& nums) {
         int sum=nums[0], max_sum=nums[0];
        for(int i=1; i<nums.size(); i++)
        {
            sum = max(nums[i], sum+nums[i]);
            if(sum>max_sum)
            {
                max_sum=sum;
            }
        }
        return max_sum;
    }
 */

/*
int max(int a, int b)
 {
     int temp = a>b?a:b;
     return temp;
 }
int maxSubArray(const int* A, int n1) {
    int i,j,curr_sum=A[0],max_sum=A[0];
    for(i=1;i<n1;i++)
    {
        curr_sum = max(A[i], curr_sum+A[i]);
        max_sum = max(curr_sum,max_sum);

    }
    return max_sum;
}
 */