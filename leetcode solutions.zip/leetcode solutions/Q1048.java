package com.company;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;

public class Q1048 {
    public int longestStrChain(String[] words) {
        int ans = 0;
        HashMap<String,Integer> map = new HashMap<>();
        Arrays.sort(words, new Comparator<String>() {
            @Override
            public int compare(final String s1, final String s2) {
                return s1.length() < s2.length() ? -1 : 1;
            }
        });
        for (String word : words) {

            for (int i=0;i<word.length();i++)
            {
                String predecessor = word.substring(0,i)  + word.substring(i+1);
                map.put(word,Math.max(map.getOrDefault(word,0),map.getOrDefault(predecessor,0)+1));
            }
            ans = Math.max(ans,map.get(word));
        }
        return ans;
    }
    public static void main(String[] args) {
        String[] words = {"abcd","dbqca"};
        System.out.println(new Q1048().longestStrChain(words));
    }
}
