package com.company;

public class Q3s {
    public int lengthOfLongestSubstring(String s)
    {
        int max=0,l=0,r=1,maxsofar=0;
        while(r<s.length())
        {
            if (s.charAt(l)!=s.charAt(r))
            {
                maxsofar = r-l+1;
                r++;
                max = Math.max(max,maxsofar);
            }
            else
            {
                r++;
                l=r-1;
            }
        }
        return max;
    }
    public static void main(String[] args) {
        String s = "abcabcbb";
        System.out.println(new Q3s().lengthOfLongestSubstring(s));
    }
}
