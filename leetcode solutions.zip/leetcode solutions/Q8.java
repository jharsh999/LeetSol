package com.company;

public class Q8 {
    public int myAtoi(String s) {
        s = s.trim();
        if (s == null || s.length() < 1)
            return 0;

        // trim white spaces


        char sign = '+';

        // check negative or positive
        int i = 0;
        if (s.charAt(0) == '-') {
            sign = '-';
            i++;
        } else if (s.charAt(0) == '+') {
            i++;
        }
        // use double to store result
        double result = 0;

        // calculate value
        while (i<s.length() && s.charAt(i) >= '0' && s.charAt(i) <= '9') {
            result = result * 10 + (s.charAt(i) - '0');
            i++;
        }

        if (sign == '-')
            result = -result;

        if (result < -2147483648)
            return -2147483648;
        if (result > 2147483647)
            return 2147483647;

        return (int) result;
    }
    public static void main(String[] args) {
        String s = " ";
        System.out.println(new Q8().myAtoi(s));
    }
}
