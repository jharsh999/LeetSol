package com.company;


public class Q142 {
    public ListNode detectNode(ListNode head)
    {
        ListNode meet = detectCycle(head);
        if (meet==null) return null;
        ListNode start = head;
        while(start!=meet)
        {
            start=start.next;
            meet=meet.next;
        }
        return start;
    }
    public ListNode detectCycle(ListNode head) {
        ListNode slow = head;
        ListNode fast = head;
        while(fast!=null && fast.next!=null)
        {
            slow = slow.next;
            fast = fast.next.next;
            if (slow==fast)
            {
                return slow;
            }
        }
        return null;
    }
    public static void main(String[] args) {
        ListNode n1 = new ListNode(3);
        ListNode n2 = new ListNode(2);
        ListNode n3 = new ListNode(0);
        ListNode n4 = new ListNode(4);

        ListNode n5 = new ListNode(5);

        ListNode head = n1;
        head.next = n2;
        n2.next = n3;
        n3.next = n4;
        n4.next = n2;
        ListNode ans = new Q142().detectCycle(head);
        while(ans!=null)
        {
            System.out.println(ans.val);
            ans = ans.next;
        }
    }
}
