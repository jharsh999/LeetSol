package com.company;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class Q128 {
    public int longestConsecutive(int[] nums)
    {
        int max=0;
        Set<Integer> set = new HashSet<>();
        for (int num : nums)
        {
            set.add(num);
        }
//        0372584601
        for (int num : set)
        {
            if (!set.contains(num-1)) {
                int curr = num;
                int count = 1;

                while (set.contains(curr + 1)) {
                    curr += 1;
                    count += 1;
                }
                max = Math.max(max,count);
            }
        }
        return max;
    }
    public static void main(String[] args) {
        int[] nums = {0,3,7,2,5,8,4,6,0,1};
        System.out.println(new Q128().longestConsecutive(nums));
    }
}
//    public int longestConsecutive(int[] nums) {
//        if (nums.length == 0) {
//            return 0;
//        }
//        Arrays.sort(nums);
//        int max=1,count=1;
//        for (int i=1;i<nums.length;i++)
//        {
//            if(nums[i]!=nums[i-1])
//            {
//                if (nums[i-1]+1==nums[i])
//                {
//                    count+=1;
//                }
//                else{
//                    max = Math.max(max,count);
//                    count=1;
//                }
//            }
//        }
//        return Math.max(max,count);
//    }