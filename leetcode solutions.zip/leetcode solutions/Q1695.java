package com.company;

import java.util.HashSet;

public class Q1695 {
    public int maximumUniqueSubarray(int[] nums) {
        HashSet<Integer> set = new HashSet<Integer>();
        int sum=0;
        int max=Integer.MIN_VALUE;


        int i=0;
        int j=0;
        while(i<nums.length && j<nums.length){
            if(!set.contains(nums[j])){
                sum+=nums[j];
                max = Math.max(sum, max);
                set.add(nums[j++]);
            }
            else{
                //Remove the leftmost element from sliding window
                sum=sum-nums[i];
                set.remove(nums[i++]);
            }
        }
        return max;
    }
    public static void main(String[] args) {
        int[] nums = {4,2,4,5,6};
        System.out.println(new Q1695().maximumUniqueSubarray(nums));
    }
}
