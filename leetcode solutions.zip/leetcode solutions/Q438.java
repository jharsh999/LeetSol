package com.company;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Q438 {
    static int NO_OF_CHARS = 256;
    public List<Integer> findAnagrams(String s, String p) {
        List<Integer> result = new ArrayList<>();
        int n1=s.length(),n2=p.length();
        for (int i=0;i<=n1-n2;i++)
        {
            if (isAnagram(s.substring(i,i+n2).toCharArray(),p.toCharArray()))
            {
                result.add(i);
            }
        }
        return result;
    }
    static boolean isAnagram(char str1[], char str2[])
    {

        int count1[] = new int[NO_OF_CHARS];
        Arrays.fill(count1, 0);
        int count2[] = new int[NO_OF_CHARS];
        Arrays.fill(count2, 0);
        int i;

        for (i = 0; i < str1.length && i < str2.length;
             i++) {
            count1[str1[i]]++;
            count2[str2[i]]++;
        }
        for (i = 0; i < NO_OF_CHARS; i++)
            if (count1[i] != count2[i])
                return false;

        return true;
    }

    public static void main(String[] args) {
        String s = "cbaebabacd", p = "abc";
        System.out.println(new Q438().findAnagrams(s,p));
    }
}
//    public boolean isAnagram(String s1,String s2)
//    {
//        char[] st1= s1.toCharArray();
//        char[] st2= s2.toCharArray();
//        Arrays.sort(st1);
//        Arrays.sort(st2);
//        for (int i=0;i<st1.length;i++)
//        {
//            if (st1[i]!=st2[i]) return false;
//        }
//        return true;
//    }