package com.company;

import java.util.Arrays;

public class Q27 {
    static int removeElement(int[] nums, int val) {
       int dupVal = 0;
        for (int i=0; i< nums.length;i++)
        {
            if (nums[i]==val)
            {
                nums[i] = Integer.MAX_VALUE;
                dupVal++;
            }
        }
        Arrays.sort(nums);
        for (int j = 0; j<nums.length; j++)
        {
            System.out.println(nums[j]);
        }
        return nums.length-dupVal;
    }
    public static void main(String[] args) {
        int[] nums = {0,1,2,2,3,0,4,2};
        int val = 2;
        System.out.println(removeElement(nums,2));

    }
}
