package com.company;

import java.util.Stack;

public class Q150 {
    public int evalRPN(String[] tokens) {
        int a,b;
        Stack<Integer> st = new Stack<>();
        for (String s : tokens)
        {
            if (s.equals("+")) st.push(st.pop()+st.pop());
            else if (s.equals("*")) st.push(st.pop()*st.pop());
            else if (s.equals("-")){
                 b = st.pop();
                 a = st.pop();
                st.push(a-b);
            }
            else if (s.equals("/")){
             b = st.pop();
             a = st.pop();
            st.push(a/b);
        }
            else
                st.push(Integer.parseInt(s));
        }
        return st.peek();
    }
    public static void main(String[] args) {
        String[] tokens = {"10","6","9","3","+","-11","*","/","*","17","+","5","+"};
        System.out.println(new Q150().evalRPN(tokens));
    }
}
