package com.company;

public class LCP {
    public String longestCommonPrefix(String[] strs)
    {
        for(int i=0 ; i< strs.length ; i++) {
            System.out.println(strs[i]);
        }

     return "";
    }

    public static void main(String[] args) {
        String[] strs =  {"flower","flow","flight"};
        LCP l1 = new LCP();
        l1.longestCommonPrefix(strs);
    }

}
