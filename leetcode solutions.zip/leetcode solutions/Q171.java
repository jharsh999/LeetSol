package com.company;

public class Q171 {
    public int titleToNumber(String columnTitle) {
        int prev =0;
        for (int i=0;i<columnTitle.length();i++)
        {
            prev = (prev*26) + (columnTitle.charAt(i)-'A') +1;
        }
        return prev;
    }
    public static void main(String[] args) {
        String columnTitle = "AB";
        Q171 q = new Q171();
        System.out.println(q.titleToNumber(columnTitle));
    }
}
