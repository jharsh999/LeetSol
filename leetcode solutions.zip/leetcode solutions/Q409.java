package com.company;

import java.util.HashSet;
import java.util.Set;

public class Q409 {
    public int longestPalindrome(String s) {
        Set<Character> set = new HashSet<>();
        int count=0;
        for (int i=0;i<s.length();i++)
        {
            if (set.contains(s.charAt(i)))
            {
                count +=2;
                set.remove(s.charAt(i));
            }
            else
            {
                set.add(s.charAt(i));
            }
        }
        if (set.size()>0) return count+1;
        return count;
    }

    public static void main(String[] args) {
        System.out.println(new Q409().longestPalindrome("a"));
    }
}
