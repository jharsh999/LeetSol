package com.company;



class ListNode {
    int val;
    ListNode next;
    ListNode() {}
    ListNode(int val) { this.val = val; }
    ListNode(int val, ListNode next) { this.val = val; this.next = next; }
}
public class Q21 {
    public ListNode mergeTwoLists(ListNode list1, ListNode list2) {
        ListNode ans = new ListNode();
        ListNode head = ans;
        while(list1!=null && list2!=null)
        {
            if (list1.val>=list2.val)
            {
                ans.next=list2;
                list2 = list2.next;
            }
            else
            {
                ans.next=list1;
                list1=list1.next;
            }
            ans = ans.next;
        }
        while(list1!=null)
        {
            ans.next = list1;
            list1=list1.next;
            ans= ans.next;
        }
        while(list2!=null)
        {
            ans.next = list2;
            list1=list1.next;
            ans= ans.next;
        }
        return head.next;
    }

    public static void main(String[] args) {
        Q21 q2 = new Q21();
        ListNode n1 = new ListNode(1);
        ListNode n2 = new ListNode(2);
        ListNode n3 = new ListNode(4);
        ListNode n4 = new ListNode(1);
        ListNode n5 = new ListNode(3);
        ListNode n6 = new ListNode(6);

        ListNode head1 = n1;
        ListNode head2 = n4;
        head1.next = n2;
        n2.next = n3;
        n3.next = null;

        head2.next = n5;
        n5.next = n6;
        n6.next = null;

        ListNode ans = new Q21().mergeTwoLists(head1,head2);
        while(ans!=null)
        {
            System.out.println(ans);
            ans = ans.next;
        }
    }
}
