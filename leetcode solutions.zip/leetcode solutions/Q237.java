package com.company;

import javax.swing.event.ListDataEvent;

public class Q237 {
    public class ListNode {
      int val;
      ListNode next;
      ListNode(int x) { val = x; }
  }
  public void insert(int val,int pos,ListNode head)
  {
    ListNode toAdd = new ListNode(val);
    if(pos==0)
    {
      toAdd.next = head;
      head = toAdd;
    }
    ListNode prev = head;
    for (int i=0;i<pos-1;i++)
    {
      prev = prev.next;
    }
    toAdd.next = prev.next;
    prev.next = toAdd;
  }
  public void deleteNode(ListNode node) {
      node.val = node.next.val;
      node.next = node.next.next;
  }
  public void delete(int pos,ListNode head)
  {
    if(pos==0)
    {
      head = head.next;
    }
    ListNode prev = head;
    for (int i=0;i<pos-1;i++)
    {
      prev = prev.next;
    }
    prev.next = prev.next.next;
  }
  public void traverse(ListNode head)
  {
    ListNode current = head;
    while (current!=null)
    {
      System.out.println(current.val);
      current = current.next;
    }
  }
    public static void main(String[] args) {
       Q237 q = new Q237();
        ListNode n1 = q.new ListNode(10);
      ListNode n2= q.new ListNode(20);
      ListNode n3 = q.new ListNode(30);
      ListNode n4= q.new ListNode(40);
      ListNode n5 = q.new ListNode(50);

      ListNode head = n1;
      head.next = n2;
      n2.next = n3;
      n3.next = n4;
      n4.next = n5;
      n5.next = null;

      q.insert(45,4,head);
      q.traverse(head);

      System.out.println(" ");
      q.delete(4,head);
      q.traverse(head);

      System.out.println(" ");
      q.deleteNode(n2);
      q.traverse(head);

    }
}
