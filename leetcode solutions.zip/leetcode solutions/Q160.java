package com.company;

public class Q160 {
    public class ListNode {
        int val;
        ListNode next;
        ListNode() {}
        ListNode(int val) { this.val = val; }
        ListNode(int val, ListNode next) { this.val = val; this.next = next; }
    }
    public ListNode getIntersectionNode(ListNode headA, ListNode headB)
    {
       int a=0,b=0;
       ListNode currA=headA,currB=headB;
       while (currA!=null)
       {
           currA=currA.next;
           a++;
       }
        while (currB!=null)
        {
            currB=currB.next;
            b++;
        }
        int k = Math.abs(b-a);
        if (b>a)
        {
            while(k>0)
            {
                headB=headB.next;
                k--;
            }
        }
        else
        {
            while(k>0)
            {
                headA=headA.next;
                k--;
            }
        }
        while (headA!=headB && headA.next!=null && headB.next!=null)
        {
            headA=headA.next;
            headB=headB.next;
        }
        if (headA!=headB) return null;
        return headA;
    }
    public static void main(String[] args) {
         Q160 q = new Q160();
        ListNode n1 = q.new ListNode(4);
        ListNode n2= q.new ListNode(1);

        ListNode n3 = q.new ListNode(8);
        ListNode n4= q.new ListNode(4);
        ListNode n5 = q.new ListNode(5);

        ListNode n6 = q.new ListNode(5);
        ListNode n7= q.new ListNode(6);
        ListNode n8 = q.new ListNode(1);

        ListNode head1 = n1;
        head1.next=n2;
        n2.next=n3;

        ListNode head2 = n6;
        head2.next=n7;
        n7.next=n8;
        n8.next=n3;

        n3.next=n4;
        n4.next=n5;
        n5.next=null;

        System.out.println(q.getIntersectionNode(head1,head2).val);


    }
}
