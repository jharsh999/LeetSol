package com.company;

import java.util.Stack;

public class Q58 {
    public int lengthOfLastWord(String s) {
        int ans = 0;
        boolean char_flag = false;
        for (int i=s.length()-1;i>=0;i--)
        {
            if (Character.isLetter(s.charAt(i))){
                char_flag = true;
                ans++;
            }
            else
            {
                if (char_flag==true) return ans;
            }
        }
        return ans;
    }
    public static void main(String[] args) {
        String s = "   fly me   to   the moon  ";
        System.out.println(new Q58().lengthOfLastWord(s));
    }
}
