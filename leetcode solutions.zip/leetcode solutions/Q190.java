package com.company;

public class Q190 {
    public int reverseBits(int n)
    {
        for (int i = 0; i < 16; i++)
        {
            int temp = (n & (1 << i));
            temp = temp==0? 0: 1;
            int temp1 = (n & (1 << (31 - i)));
            temp1 = temp1==0? 0: 1;
            if (temp1 != temp)
            {
                n ^= (1 << i);
                n ^= (1 << (31 - i));
            }
        }
        return n;
    }
    public static void main(String[] args) {
        int n=43261596;
        System.out.println(new Q190().reverseBits(n));
    }
}
