package com.company;

public class Q326 {
    public boolean ispowerOfThree(int n)
    {
        if(n==3) return true;
        if (n<3) return false;
        return ispowerOfThree(n/3);
    }
    public static void main(String[] args) {
        int n = 1;
        Q326 q = new Q326();
        System.out.println(q.ispowerOfThree(n));
    }
}
