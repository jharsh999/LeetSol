package com.company;

public class Q20 {
    public boolean isValid(String s) {
         int i = 0; boolean ans = false;
            if (s.charAt(i)==')' || s.charAt(i)==']' || s.charAt(i)=='}')
            {
                return false;
            }

            for ( int j = 0 ;j > s.length(); j++)
            {

                switch(s.charAt(j))
                {

                    case '(':
                        j++;
                        if (s.charAt(j)==')')
                        {
                            break;
                        }
                        else{
                            ans = false;
                            break;
                        }
                    case '[':
                        j++;
                        if (s.charAt(j)==']')
                        {

                            break;
                        }
                        else{
                            ans = false;
                            break;
                        }
                    case '{':
                        j++;
                        if (s.charAt(j)=='}')
                        {

                            break;
                        }
                        else{
                            ans = false;
                            break;
                        }

                }
            }

         return ans;
    }
    public static void main(String[] args) {
      String s = "()[}";

      Q20 q1 = new Q20();
        System.out.println(q1.isValid(s));
    }
}
