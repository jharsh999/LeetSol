package com.company;

public class Q55 {

    public boolean canJump(int[] nums) {
        int max=0;
        for(int i=0;i< nums.length;i++)
        {
            if(i>max) return false;
            max = Math.max(nums[i]+i,max);
        }
        return true;
    }
    public static void main(String[] args) {
        int[] nums = {3,2,1,1,4};
        System.out.println(new Q55().canJump(nums));
    }
}
