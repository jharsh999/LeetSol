package com.company;

import java.util.HashSet;
import java.util.Set;

public class Q136 {
    public int singleNumber(int[] nums) {
        int res = 0;
        for (int i=0 ; i<nums.length; i++) {
            res = res^nums[i];
        }
        return res;
    }
    public static void main(String[] args) {

        int[] nums = {1,2,6,1,2};
        Q136 q = new Q136();
        System.out.println(q.singleNumber(nums));
    }
}
//    My algo but O(nlogn) time complexity:-
//
//    public int singleNumber(int[] nums) {
//        int element=nums[0];
//        if(nums.length==1) return nums[0];
//        Arrays.sort(nums);
//        for (int i = 0; i<nums.length-1 ; i=i+2)
//        {
//            if (nums[i]!=nums[i+1]) return nums[i];
//        }
//        if(nums.length%2 == 1)
//        {
//            return nums[nums.length-1];
//        }
//        return 0;
//    }