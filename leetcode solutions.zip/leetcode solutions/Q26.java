package com.company;

import java.util.Arrays;

public class Q26 {
    static int removeDuplicates(int[] nums) {
     int i=0,NoOfDuplicates=0;
     for (i=0;i< nums.length-1;i++)
     {
         if (nums[i]==nums[i+1])
         {
             nums[i]=Integer.MAX_VALUE;
             NoOfDuplicates++;
         }
     }
        System.out.println(NoOfDuplicates);
        Arrays.sort(nums);
        return nums.length-NoOfDuplicates;

    }
    public static void main(String[] args) {
        int[] nums = {0,0,1,1,1,2,2,3,3,4};
        System.out.println(removeDuplicates(nums));

    }
}
