package com.company;

public class Q733 {
    public int[][] floodFill(int[][] image, int sr, int sc, int color) {
        int oldColor = image[sr][sc];
        if (oldColor!=color) dfs(image,sr,sc,color,oldColor);
        return image;
    }
    public void dfs(int[][] image, int sr, int sc, int color,int oldcolor)
    {
     if (image[sr][sc]==oldcolor)
     {
         image[sr][sc]=color;
         if (sr>0) dfs(image,sr-1,sc,color,oldcolor);
         if (sc>0) dfs(image,sr,sc-1,color,oldcolor);
         if (sr<image.length-1) dfs(image,sr+1,sc,color,oldcolor);
         if (sc<image.length-1) dfs(image,sr,sc+1,color,oldcolor);
     }
    }
    public static void main(String[] args) {
        int[][] image = {{1,1,1},{1,1,0},{1,0,1}};
        image = new Q733().floodFill(image,1,1,2);
        for (int i=0;i<image.length;i++)
        {
          for (int j=0;j< image[0].length;j++)
          {
              System.out.println(image[i][j]);
          }
        }
    }
}