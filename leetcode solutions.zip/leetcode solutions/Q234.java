package com.company;

public class Q234 {
    public class ListNode {
      int val;
      ListNode next;
      ListNode() {}
      ListNode(int val) { this.val = val; }
      ListNode(int val, ListNode next) { this.val = val; this.next = next; }
  }
    public boolean isPalindrome(ListNode head) {
      if(head==null ||head.next==null) return true;
      if (head.next.next==null)
      {
        if(head.val==head.next.val) return true;
        return false;
      }
      ListNode mid = middle(head);
      ListNode last = reverse(mid.next);
      ListNode curr = head;
      while (last!=null)
      {
        if(curr.val!= last.val) return false;
        curr=curr.next;
        last=last.next;
      }
      return true;
    }

  private ListNode middle(ListNode head) {
      ListNode slow = head;
      ListNode fast = head;
      while(fast!=null && fast.next!=null)
      {
        slow = slow.next;
        fast = fast.next.next;
      }
      return slow;
  }

  public ListNode reverse(ListNode head)
    {
      ListNode curr = head;
      ListNode prev = null;
      while (curr!=null)
      {
        ListNode temp = curr.next;
        curr.next = prev;
        prev = curr;
        curr = temp;
      }
      return prev;
    }
    public static void main(String[] args) {
      Q234 q = new Q234();
      ListNode n1 = q.new ListNode(1);
      ListNode n2= q.new ListNode(2);
//      ListNode n3 = q.new ListNode(2);
//      ListNode n4= q.new ListNode(3);
//      ListNode n5 = q.new ListNode(1);
//      ListNode n6 = q.new ListNode(2);
//      ListNode n7= q.new ListNode(3);
//      ListNode n8 = q.new ListNode(1);

      ListNode head = n1;
      head.next = null;
//      n2.next = null;
//      n3.next = n4;
//      n4.next = n5;
//      n5.next = n6;
//      n6.next = n7;
//      n7.next = n8;
//      n8.next = null;
      System.out.println(q.isPalindrome(head));
    }
}
