package com.company;

public class cont {
    public boolean checkXMatrix(int[][] grid) {
        for (int i=0;i<grid.length;i++)
        {
            for (int j=0;j< grid.length;j++)
            {
                if (i==j)
                {
                    if (grid[i][i]==0) return false;
                }
                else if (i+j== grid.length-1)
                {
                    if (grid[i][j]==0) return false;
                }
                else
                {
                    if (grid[i][j]!=0) return false;
                }
            }
        }
        return true;
    }
    public static void main(String[] args) {
        int[][] grid = {{5,7,0},{0,3,1},{0,5,0}};
        System.out.println(new cont().checkXMatrix(grid));
    }
}
