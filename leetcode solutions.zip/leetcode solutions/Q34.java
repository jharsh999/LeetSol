package com.company;

public class Q34 {
    public int[] searchRange(int[] nums, int target) {
        return new int[]{findFirst(nums,target),findLast(nums,target)};
    }
    public static int findFirst(int[] nums, int target)
    {
        int ans = -1;
        int s = 0;
        int e = nums.length - 1;
        while(s <= e){
            int mid =s+ (e-s) / 2;
            if (nums[mid] < target)
                s = mid + 1;
            else if (nums[mid] > target)
                e = mid - 1;
            else  {
                ans = mid;
                e = mid - 1;
            }
        }
        return ans;
    }
    public static int findLast(int[] nums, int target)
    {
        int ans = -1;
        int s = 0;
        int e = nums.length - 1;
        while(s <= e){
            int mid =s+ (e-s) / 2;
            if (nums[mid] < target)
                s = mid + 1;
            else if (nums[mid] > target)
                e = mid - 1;
            else  {
                ans = mid;
                s = mid + 1;
            }
        }
        return ans;
    }
    public static void main(String[] args) {
        int[] nums = {5,7,7,8,8,10};
        int[] ans = new Q34().searchRange(nums,8);
        for (int i:ans){
            System.out.println(i);
        }

    }
}
