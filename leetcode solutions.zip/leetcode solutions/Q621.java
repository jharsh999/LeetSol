package com.company;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;

public class Q621 {
    public int leastInterval(char[] tasks, int n) {

        int taskCount[] = new int[26];

        for(char each : tasks){
            taskCount[each-'A'] += + 1;
        }

        Arrays.sort(taskCount);

        int maxSlots = (taskCount[25]-1)*n;
        for(int i = 24; i >= 0 ; i--){
            maxSlots -= Math.min(taskCount[i], taskCount[25]-1);
        }
        System.out.println(maxSlots);
        return maxSlots > 0 ? maxSlots + tasks.length : tasks.length;
    }
    public static void main(String[] args) {
        char[] tasks = {'A','A','A','B','C','D','E','F','G'};
        System.out.println(new Q621().leastInterval(tasks,2));
    }
}
