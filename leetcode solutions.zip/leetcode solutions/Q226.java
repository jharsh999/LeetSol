package com.company;

public class Q226 {
    public class TreeNode {
      int val;
      TreeNode left;
      TreeNode right;
      TreeNode() {}
      TreeNode(int val) { this.val = val; }
      TreeNode(int val, TreeNode left, TreeNode right) {
          this.val = val;
          this.left = left;
          this.right = right;
      }
  }
        public TreeNode invertTree(TreeNode root) {
        if (root==null) return null;
        invertTree(root.left);
        invertTree(root.right);

        TreeNode temp = root.left;
        root.left=root.right;
        root.right=temp;
        return root;
        }
    public static void main(String[] args) {
        Q226 q = new Q226();
        TreeNode root = q.new TreeNode(3);
        TreeNode n1 = q.new TreeNode(9);
        TreeNode n2 = q.new TreeNode(20);

        root.left=n1;
        root.right=n2;
        n1.left=null;
        n1.right=null;
        n2.left=null;
        n2.right=null;

        TreeNode ans = new Q226().invertTree(root);

    }
}
