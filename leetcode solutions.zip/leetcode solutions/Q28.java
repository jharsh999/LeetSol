package com.company;

public class Q28 {
    static int strStr(String haystack, String needle) {

        int j = 0;
        for(int i=0 ; i<haystack.length(); i++)
        {
            if (haystack.charAt(i) == needle.charAt(j))
            {

            }
        }
        //code here

        return 0;
    }
    public static void main(String[] args) {
        String haystack = "hello", needle = "ll";
        System.out.println(strStr(haystack,needle));
    }
}
