package com.company;

public class Q21s {
        public ListNode mergeTwoLists(ListNode l1, ListNode l2) {

            ListNode result = new ListNode();
            ListNode head = result;
            while(l1!=null && l2!=null){
                if(l1.val<l2.val){
                    result.next = l1;
                    l1 = l1.next;
                }else{
                    result.next = l2;
                    l2 = l2.next;
                }
                result = result.next;
            }

            if(l1!=null){
                result.next=l1;
            }else{
                result.next=l2;
            }

            return head.next;
        }

    public static void main(String[] args) {
        Q21s q2 = new Q21s();
        ListNode n1 = new ListNode(1);
        ListNode n2 = new ListNode(2);
        ListNode n3 = new ListNode(4);
        ListNode n4 = new ListNode(1);
        ListNode n5 = new ListNode(3);
        ListNode n6 = new ListNode(6);

        ListNode head1 = n1;
        ListNode head2 = n4;
        head1.next = n2;
        n2.next = n3;
        n3.next = null;

        head2.next = n5;
        n5.next = n6;
        n6.next = null;

        ListNode ans = new Q21().mergeTwoLists(head1,head2);
        while(ans.next!=null)
        {
            System.out.println(ans.val);
            ans = ans.next;
        }
    }
}
