package com.company;

import java.util.Stack;

public class Q844 {
        public boolean backspaceCompare(String s, String t) {
        Stack<Character> s1 = new Stack<>();
        Stack<Character> s2 = new Stack<>();
        for (int i=0;i<s.length();i++)
        {
            if (Character.isLetter(s.charAt(i))) s1.push(s.charAt(i));
            else if (!s1.isEmpty()) s1.pop();
        }
        for (int i=0;i<t.length();i++)
        {
            if (Character.isLetter(t.charAt(i))) s2.push(t.charAt(i));
            else if (!s2.isEmpty())s2.pop();
        }
        while(!s1.isEmpty() && !s2.isEmpty())
        {
            char c1=s1.pop();
            char c2=s2.pop();
            if (c1!=c2) return false;
        }
        if (!s1.isEmpty() || !s2.isEmpty()) return false;
        return true;
    }
    public static void main(String[] args) {
        System.out.println(new Q844().backspaceCompare("ab#c","ad#c"));
    }
}
