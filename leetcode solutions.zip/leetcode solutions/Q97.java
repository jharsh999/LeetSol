package com.company;

public class Q97 {
    public boolean isInterleave(String s1, String s2, String s3) {
        int i=0,j=0,k=0;
        while(k<s3.length())
        {

            if (s1.charAt(i)==s3.charAt(k))
            {
                i++;
                k++;
            }
            if (s2.charAt(j)==s3.charAt(k))
            {
                j++;
                k++;
            }
            if (s1.charAt(i)!=s3.charAt(k) && s2.charAt(j)!=s3.charAt(k))
                return false;
        }
        return true;
    }
    public static void main(String[] args) {
        System.out.println(new Q97().isInterleave("aabcc","dbbca","aadbbcbcac"));
    }
}
