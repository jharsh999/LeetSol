package com.company;

public class Q206 {
     class ListNode {
      int val;
      ListNode next;
      ListNode() {}
      ListNode(int val) { this.val = val; }
      ListNode(int val, ListNode next) { this.val = val; this.next = next; }
  }
    public ListNode reverseList(ListNode head) {
         ListNode curr = head;
         ListNode prev = null;
         while (curr!=null)
//         1 - 2 - 3 - 4 - 5
         {
             ListNode temp = curr.next;
             curr.next = prev;
             prev = curr;
             curr = temp;
         }
         return prev;
    }
    public ListNode Rec_reverse(ListNode head)
    {
        if (head==null || head.next==null) return head;
        ListNode newHead = Rec_reverse(head.next);
        ListNode HeadNext = head.next;
        HeadNext.next = head;
        head.next = null;
        return newHead;
    }
    public void traverse(ListNode head)
    {
        ListNode current = head;
        while (current!=null)
        {
            System.out.println(current.val);
            current = current.next;
        }
    }
    public static void main(String[] args) {
         Q206 q = new Q206();
         ListNode n1 = q.new ListNode(10);
         ListNode n2= q.new ListNode(20);
         ListNode n3 = q.new ListNode(30);
         ListNode n4= q.new ListNode(40);
         ListNode n5 = q.new ListNode(50);

        ListNode head = n1;
        head.next = n2;
        n2.next = n3;
        n3.next = n4;
        n4.next = n5;
        n5.next = null;
        head = q.Rec_reverse(head);
        q.traverse(head);

    }
}
