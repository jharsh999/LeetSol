package com.company;

public class Q509 {
    public int fib(int n) {
        int ans = 0;
        int a=0,b=1;
        for (int i = 0; i < n-1; i++)
        {
            ans = a+b;
            a=b;
            b=ans;
        }
        return ans;
    }
    public static void main(String[] args) {
        System.out.println(new Q509().fib(0));
    }
}
