package com.company;

public class Q198 {
    public int rob(int[] nums) {
        int sum1=0,sum2=0;
        int i=0,j=1;
        while(i<nums.length && j<nums.length)
        {
            sum1+=nums[i];
            sum2+=nums[j];
            i=i+2;
            j=j+2;
        }
        return Math.max(sum1,sum2);
    }
    public static void main(String[] args) {
        int[] nums = {2,7,9,3,1};
        System.out.println(new Q198().rob(nums));
    }
}
