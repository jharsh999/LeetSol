package com.company;

public class Q240 {
    public boolean searchMatrix(int[][] matrix, int target) {
       int i=0,j=0;
        while (i<matrix.length)
        {
            if (binarysearch(matrix[i],target)) return true;
        }
        return false;
    }
    public boolean binarysearch(int[] nums,int target)
    {
        int l=0,h= nums.length-1;
        int mid=0;

        while(l<=h)
        {
            mid=l+(h-l)/2;
            if (nums[mid]==target) return true;
            if(nums[mid]>target)
            {
                h=mid-1;
            }
            else
            {
                l=mid+1;
            }
        }
        return false;
    }
    public static void main(String[] args) {
        int[][] matrix = {{1,4,7,11,15},{2,5,8,12,19},{3,6,9,16,22}
        ,{10,13,14,17,24},{18,21,23,26,30}};
        System.out.println(new Q240().searchMatrix(matrix,5));
    }
}
