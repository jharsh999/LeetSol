package com.company;

public class Q83 {
    public class ListNode {
      int val;
      ListNode next;
      ListNode() {}
      ListNode(int val) { this.val = val; }
      ListNode(int val, ListNode next) { this.val = val; this.next = next; }
  }


    public ListNode deleteDuplicates(ListNode head) {
        if(head==null) return null;
        ListNode prev =head;
        ListNode curr =head.next;
        while (curr!=null)
        {
            if(prev.val==curr.val)
            {
                curr=curr.next;
                prev.next=prev.next.next;
            }
            else
            {
                prev=prev.next;
                curr=curr.next;
            }
        }
        return head;
        }
    public void traverse(ListNode head)
    {
        ListNode current = head;
        while (current!=null)
        {
            System.out.println(current.val);
            current = current.next;
        }
    }
    public static void main(String[] args) {
        Q83 q = new Q83();
        ListNode n1 = q.new ListNode(1);
        ListNode n2= q.new ListNode(1);
        ListNode n3 = q.new ListNode(2);
        ListNode n4= q.new ListNode(3);
        ListNode n5 = q.new ListNode(3);

        ListNode head = n1;
        head.next = n2;
        n2.next = null;
        n3.next = null;
        n4.next = n5;
        n5.next = null;

        q.traverse(q.deleteDuplicates(head));
    }
}
