package com.company;

public class Q74 {
    public boolean searchMatrix(int[][] matrix, int target) {
        for (int i=0;i<matrix.length;i++)
        {
            if(matrix[i][0]<=target && matrix[i][matrix[0].length-1]>=target)
            {
                if(binarysearch(matrix[i],target)) return true;}
        }
        return false;
    }
    public boolean binarysearch(int[] nums,int target)
    {
        int l=0,h= nums.length-1;
        int mid=0;

        while(l<=h)
        {
            mid=l+(h-l)/2;
            if (nums[mid]==target) return true;
            if(nums[mid]>target)
            {
                h=mid-1;
            }
            else
            {
                l=mid+1;
            }
        }
        return false;
    }

    public static void main(String[] args) {

        int[][] matrix = {{1,3,5,7}};
        System.out.println(new Q74().searchMatrix(matrix,3));
    }
}
