package com.company;

public class Q371 {
    public int getSum(int a, int b) {
        int carry=0;
        while(b!=0)
        {
            carry=a&b;
            a=a^b;
            b=carry<<1;
        }
        return a;
    }
    public static void main(String[] args) {
        int a=2,b=3;
        System.out.println(new Q371().getSum(a,b));
    }
}
