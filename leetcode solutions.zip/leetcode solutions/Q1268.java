package com.company;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Q1268 {
    public List<List<String>> suggestedProducts(String[] products, String searchWord) {
        List<List<String>> result=new ArrayList();
        Arrays.sort(products);
        String str="";
        for(int i=0;i<searchWord.length();i++)
        {
            List<String> tempList=new ArrayList();
            str+=searchWord.charAt(i);
            for(int j=0;j<products.length;j++)
            {
                if(products[j].startsWith(str))
                {
                    tempList.add(products[j]);
                    if(tempList.size()==3)
                        break;
                }
            }
            result.add(tempList);
        }
        return result;
    }
    public static void main(String[] args) {
        String[] products = {"mobile","mouse","moneypot","monitor","mousepad"};
        String searchWord = "mouse";
        List<List<String>> ans = new Q1268().suggestedProducts(products,searchWord);
    }
}
