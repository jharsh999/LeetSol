package com.company;

public class Q1s {
    public int[] twoSum(int[] nums, int target) {
        int left = 0 , right = nums.length - 1 , tempSum;
        while(left < right)
        {
            tempSum = nums[left] + nums[right];
            if(tempSum == target)
                return new int[]{left , right};
            if(tempSum > target)
                right--;
            else
                left++;
        }
        return new int[]{-1 , -1};
    }

    public static void main(String[] args) {
        int[] nums ={3,2,4};
        int target=9;
        int[] ans = new Q1s().twoSum(nums,target);
        for (int i : ans)
        {
            System.out.println(i);
        }
    }
}
