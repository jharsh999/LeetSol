package com.company;

import java.util.Stack;

public class Q394 {
    public String decodeString(String s) {
        Stack<Integer> counts = new Stack<>();
        Stack<String> result = new Stack<>();
        String res = "";
        int index=0;

        while(index<s.length())
        {
            if (Character.isDigit(s.charAt(index)))
            {
                int count = 0;
                while (Character.isDigit(s.charAt(index)))
                {
                    count =10*count+(s.charAt(index)-'0');
                    index++;
                }
                counts.push(count);
            }
            else if (s.charAt(index)=='[')
            {
                result.push(res);
                res="";
                index++;
            }
            else if (s.charAt(index)==']')
            {
                StringBuilder temp = new StringBuilder(result.pop());
                int count =counts.pop();
                for (int i=0;i<count;i++)
                {
                    temp.append(res);
                }
                res = temp.toString();
                index++;
            }
            else
            {
                res +=s.charAt(index);
                index++;
            }
        }
        return res;
    }
    public static void main(String[] args) {
        System.out.println(new Q394().decodeString("3[a]2[bc]"));
    }
}
