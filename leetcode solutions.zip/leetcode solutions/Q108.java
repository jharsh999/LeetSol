package com.company;
/*
class TreeNode
{
    int val;
    TreeNode left;
    TreeNode right;
    TreeNode() {}
    TreeNode(int val) { this.val = val; }
    TreeNode(int val, TreeNode left, TreeNode right)
    {
        this.val = val;
        this.left = left;
        this.right = right;
    }
}
 */
public class Q108 {
    public TreeNode sortedArrayToBST(int[] nums) {
        return insert(nums,0, nums.length-1);

    }
    public TreeNode insert(int[] nums,int l,int h)
    {
        if(l>h)
        {
            return null;
        }
        if (l==h)
        {
            return new TreeNode(nums[l]);
        }
        int mid = (l + (h-l)/2);
        TreeNode head = new TreeNode(nums[mid]);
        head.left = insert(nums,l,mid-1);
        head.right = insert(nums,mid+1,h);
        return head;
    }
    public void preOrder(TreeNode head)
    {
        if(head == null)
        {
            return;
        }
        System.out.println(head.val + "");
        preOrder(head.left);
        preOrder(head.right);
    }

    public static void main(String[] args) {
        int[] nums = {-10,-3,0,5,9};
        Q108 q = new Q108();
        TreeNode head = q.sortedArrayToBST(nums);
        q.preOrder(head);
    }
}
