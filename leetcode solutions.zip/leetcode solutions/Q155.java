package com.company;

import java.util.Stack;

public class Q155 {
    Stack<Integer> st = new Stack<>();
    Stack<Integer> minimum = new Stack<>();
    public Q155() {

    }

    public void push(int val) {
        if(st.isEmpty() || val<=minimum.peek()) minimum.push(val);
        st.push(val);
    }

    public void pop() {
        if(st.peek()==minimum.peek()) minimum.pop();
        st.pop();
    }

    public int top() {
        return st.peek();
    }

    public int getMin() {
        return minimum.peek();
    }
    public static void main(String[] args) {
        Q155 minStack = new Q155();
        minStack.push(-2);
        minStack.push(0);
        minStack.push(-3);
        System.out.println(minStack.getMin());
        minStack.pop();
        System.out.println(minStack.top());
        System.out.println(minStack.getMin());

    }
}
