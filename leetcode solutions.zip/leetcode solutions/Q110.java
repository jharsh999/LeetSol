package com.company;

public class Q110 {
    public class TreeNode {
        int val;
        TreeNode left;
        TreeNode right;
        TreeNode() {}
        TreeNode(int val) { this.val = val; }
        TreeNode(int val, TreeNode left, TreeNode right) {
            this.val = val;
            this.left = left;
            this.right = right;
        }
    }
    public int dfsheight(TreeNode root)
    {
        if (root==null) return 0;

        int lh=dfsheight(root.left);
        if (lh==-1)return -1;
        int rh=dfsheight(root.right);
        if (rh==-1) return -1;

        if (Math.abs(rh-lh)>1) return -1;
        return Math.max(rh,lh)+1;
    }
    public boolean isBalanced(TreeNode root) {
        return dfsheight(root)!=-1;
    }
    public static void main(String[] args) {
        Q110 q = new Q110();
        TreeNode root = q.new TreeNode(3);
        TreeNode n1 = q.new TreeNode(9);
        TreeNode n2 = q.new TreeNode(20);
        TreeNode n3 = q.new TreeNode(15);
        TreeNode n4 = q.new TreeNode(7);

        root.left=n1;
        root.right=n2;
        n1.left=null;
        n1.right=null;
        n2.left=n3;
        n2.right=n4;
        n3.left=null;
        n3.right=null;
        n4.left=null;
        n4.right=null;
        System.out.println(new Q110().isBalanced(root));
    }
}
