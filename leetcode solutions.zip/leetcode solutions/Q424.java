package com.company;

public class Q424 {
    public int characterReplacement(String s, int k)
    {
        int max=0;
        int maxSofar=0;
        int pointer=0;
        int copyofk=k;
        for (int i=0;i<s.length();i++)
        {
            if (s.charAt(pointer)==s.charAt(i))
            {
                maxSofar++;
            }
            else if (k!=0) {
                maxSofar++;
                k--;
            }
            else{
                pointer++;
                i=pointer;
                max=Math.max(max,maxSofar);
                maxSofar=0;
            }
        }
        return max;
    }
    public static void main(String[] args) {
        System.out.println(new Q424().characterReplacement("ABAB",2));
    }
}
