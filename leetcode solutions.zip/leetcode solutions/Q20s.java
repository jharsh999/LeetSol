package com.company;

import java.util.Stack;

public class Q20s {

    public static boolean isValid(String s)
    {
        Stack<Character> st = new Stack<>();
        char[] sc = s.toCharArray();
        for (char c : sc)
        {
            switch (c)
            {
                case '(': st.push(c); break;
                case '{': st.push(c); break;
                case '[': st.push(c); break;
                case ')':
                    if (st.empty() || st.peek()!='(') return false;
                    else st.pop(); break;
                case '}':
                    if (st.empty() || st.peek()!='{') return false;
                    else st.pop(); break;
                case ']':
                    if (st.empty() || st.peek()!='[') return false;
                    else st.pop(); break;
                default: ;
            }
        }
        return st.isEmpty();
    }
    public static void main(String[] args) {
        String s = "()";
        System.out.println(isValid(s));
    }

}
