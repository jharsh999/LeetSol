package com.company;

public class Q141 {
    class ListNode {
      int val;
      ListNode next;
      ListNode(int x) {
          val = x;
          next = null;
      }
 }
    public boolean hasCycle(ListNode head) {
        ListNode slow=head,fast=head;
        while(fast!=null && fast.next!=null)
        {
            slow=slow.next;
            fast=fast.next.next;
            if (slow==fast) return true;
        }
        return false;
    }
    public static void main(String[] args) {
        Q141 q = new Q141();
        ListNode n1 = q.new ListNode(3);
        ListNode n2= q.new ListNode(2);
        ListNode n3 = q.new ListNode(0);
        ListNode n4= q.new ListNode(-4);
//        ListNode n5 = q.new ListNode(1);
//        ListNode n6 = q.new ListNode(2);
//        ListNode n7= q.new ListNode(3);
//        ListNode n8 = q.new ListNode(1);

        ListNode head = n1;
        head.next = n2;
        n2.next = n1;
//        n3.next = n4;
//        n4.next = n2;
////        n5.next = n6;
//        n6.next = n7;
//        n7.next = n8;
//        n8.next = null;
        System.out.println(q.hasCycle(head));
    }
}
