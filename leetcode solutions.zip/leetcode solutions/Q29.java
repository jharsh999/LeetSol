package com.company;

import static java.lang.Math.abs;

public class Q29 {
    public int divide(int dividend, int divisor) {

        long dd = abs(dividend), dv = abs(divisor);

        int res=0;
        while(dv<=dd) {
            long sum=dv, count=1;
            while(sum<=dd-sum) {
                sum=2*sum;
                count+=count;
            }
            res+=count;
            dd-=sum;
        }
//        sum = 3 1  6 3
//        res = 0+2  2+3
//        dd  = 22
        if((dividend<0&&divisor>0) || (dividend>0&&divisor<0)) return -res;

        return res;
    }
    public static void main(String[] args) {
        System.out.println(new Q29().divide(25,3));
    }
}
