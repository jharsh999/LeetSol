package com.company;

public class Q33 {
    public int search(int[] nums, int target) {
        int mid,l=0,h=nums.length-1;
        while(l<=h)
        {
            mid=(l+h)/2;
            if (nums[mid]==target) return mid;
            else if (nums[mid]>=nums[l]){
                if (target>=nums[l] && target<nums[mid])
                    h=mid-1;
                else
                    l=mid+1;
            }
            else {
                if (target>nums[mid] && target<=nums[h])
                    l=mid+1;
                else
                    h=mid-1;
            }
        }
        return -1;
    }
    public static void main(String[] args) {
        int[] nums={4,5,6,7,0,1,2};
        System.out.println(new Q33().search(nums,0));
    }
}
