package com.company;

import java.util.Arrays;

public class Q169 {
    public int majorityElement(int[] nums) {
        Arrays.sort(nums);
        return nums[nums.length/2];
    }

    public static void main(String[] args) {
        int[] nums = {1,2,1,2,2,2};
        Q169 q = new Q169();
        System.out.println(q.majorityElement(nums));
    }
}
