package com.company;

import java.util.*;

public class Q2131 {
    public int longestPalindrome(String[] words) {
        int max=0;
        HashMap<String,Integer> map = new HashMap<>();
        for (int i=0;i< words.length;i++)
        {
            String rev = words[i].charAt(1)+""+words[i].charAt(0);
            if (map.containsKey(rev))
            {
                max+=4;
                map.put(rev, map.get(rev) - 1);
                if (map.get(rev) == 0) map.remove(rev);
                continue;
            }
            map.put(words[i], map.getOrDefault(words[i], 0) + 1);
        }
        for (String k : map.keySet()) {
            if (map.get(k) == 1 && (k.charAt(1) + "" + k.charAt(0)).equals(k)) {
                max += 2;
                break;
            }
        }
        return max;
    }
    public static void main(String[] args)
    {
        String[] words = {"ab","ty","yt","lc","cl","ab"};
        System.out.println(new Q2131().longestPalindrome(words));
    }
}
