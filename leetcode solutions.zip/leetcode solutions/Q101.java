package com.company;

public class Q101 {
    public static class TreeNode {
      int val;
      TreeNode left;
      TreeNode right;
      TreeNode() {}
      TreeNode(int val) { this.val = val; }
      TreeNode(int val, TreeNode left, TreeNode right) {
          this.val = val;
          this.left = left;
          this.right = right;
      }
  }

        public boolean isSymmetric(TreeNode root) {
            return check(root,root);
        }
        public boolean check(TreeNode root1 , TreeNode root2)
        {
            if (root1==null || root2 == null)
            {
                return root1 == root2;
            }
            return root1.val == root2.val && check(root1.left,root2.right) && check(root1.right,root2.left);
        }
    public static void main(String[] args) {
        TreeNode root= new TreeNode(1);
        root.left= new TreeNode(2);
        root.right= new TreeNode(2);
        root.left.left= new TreeNode(3);
        root.left.right= new TreeNode(4);
        root.right.left= new TreeNode(4);
        root.right.right= new TreeNode(3);
        Q101 q = new Q101();
        System.out.println(q.isSymmetric(root));

//      [1,2,2,3,4,4,3]
    }
}
