package com.company;

public class contest {
    public long distinctNames(String[] ideas) {
        String ideaA,ideaB;
        long max=0;
        for (int i=0;i<ideas.length;i++)
        {
            ideaA = ideas[i];
            for (int j=0;j<ideas.length;j++)
            {
                if(i==j) continue;
                ideaB = ideas[j];
                if(ideaA.charAt(0)!=ideaB.charAt(0))
                {
                    char temp1 = ideaA.charAt(0);
                    char temp2 = ideaB.charAt(0);
                    ideaA = temp2 + charRemoveAt(ideaA,0);
                    ideaB = temp1 + charRemoveAt(ideaB,0);
                    if (!check(ideaA,ideas,i) &&
                            !check(ideaB,ideas,j)) max++;
                }
            }
        }
        return max;
    }
    public static String charRemoveAt(String str, int p) {
        return str.substring(0, p) + str.substring(p + 1);
    }
    public static boolean check(String s,String[] ideas,int index)
    {
        for (int i=0;i<ideas.length;i++)
        {
            if(i==index) continue;
            if (ideas[i]==s) return true;
        }
        return false;
    }
    public static void main(String[] args) {
        String[] ideas = {"coffee","donuts","time","toffee"};
        System.out.println(new contest().distinctNames(ideas));
    }
}
