package com.company;

public class Q19 {
    public class ListNode {
      int val;
      ListNode next;
      ListNode() {}
      ListNode(int val) { this.val = val; }
      ListNode(int val, ListNode next) { this.val = val; this.next = next; }
  }

  public void traverse(ListNode head)
  {
    ListNode current = head;
    while (current!=null)
    {
      System.out.println(current.val);
      current = current.next;
    }
  }
  public ListNode removeNthFromEnd(ListNode head, int n) {
      ListNode dummy = new ListNode(0);
      dummy.next = head;
      ListNode fast=dummy;
      ListNode slow=dummy;
      for (int i=1;i<=n+1;i++)
      {
          fast=fast.next;
      }
      while(fast!=null)
      {
        fast=fast.next;
        slow=slow.next;
      }
      slow.next=slow.next.next;
      return dummy.next;
  }
    public static void main(String[] args) {
      Q19 q = new Q19();
      ListNode n1 = q.new ListNode(1);
      ListNode n2= q.new ListNode(2);
      ListNode n3 = q.new ListNode(3);
      ListNode n4= q.new ListNode(4);
      ListNode n5 = q.new ListNode(5);
      ListNode n6 = q.new ListNode(3);

      ListNode head = n1;
      head.next=n2;
      n2.next=n3;
      n3.next=n4;
      n4.next=n5;
      n5.next=null;

      ListNode head2 = n1;
      head2.next=null;

      q.traverse(q.removeNthFromEnd(head,1));
      q.traverse(q.removeNthFromEnd(head2,1));
    }
}
//    public ListNode removeNthFromEnd(ListNode head, int n) {
//      ListNode curr = head;
//      int a=0;
//      while(curr!=null)
//      {
//        curr=curr.next;
//        a++;
//      }
//      if(a==1) return null;
//      int pos=a-n;
//      delete(pos,head);
//      return head;
//    }
//  public void delete(int pos, ListNode head)
//  {
//    if(pos==0)
//    {
//      head = head.next;
//      return;
//    }
//    ListNode prev = head;
//    for (int i=0;i<pos-1;i++)
//    {
//      prev = prev.next;
//    }
//    prev.next = prev.next.next;
//  }