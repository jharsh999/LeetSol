package com.company;

public class Q50 {
    public double myPow(double x, int n) {
        double ans=1;
        long n2 = n;
        if(n2<0) n2=-1*n2;
        while (n2>0)
        {
            if (n2%2==1)
            {
                ans=ans*x;
                n2=n2-1;
            }
            else
            {
                x = x*x;
                n2 =n2/2;
            }
        }
        if (n<0) return 1.00000/ans;
        return ans;
    }
    public static void main(String[] args) {
        System.out.println(new Q50().myPow(2.00000,-2));
    }
}
