package com.company;

public class Q121 {
    public int maxProfit(int[] prices) {
        int minSoFar= prices[0] , maxPro = 0;
        for (int i=0 ; i<prices.length ; i++)
        {
            minSoFar = Math.min(minSoFar,prices[i]);
            int profit = prices[i] - minSoFar;
            maxPro = Math.max(maxPro,profit);
        }
     return maxPro;
    }

    public static void main(String[] args) {
        int [] prices = {7,1,5,3,6,4};
        Q121 q = new Q121();
        System.out.println(q.maxProfit(prices));
    }
}
