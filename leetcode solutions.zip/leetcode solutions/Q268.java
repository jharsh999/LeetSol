package com.company;

import java.util.Arrays;

public class Q268 {
    public int missingNumber(int[] nums)
    {
        int n = (nums.length*nums.length + nums.length)/2;
        int sum = 0;
        for (int i=0;i<nums.length;i++)
        {
            sum+= nums[i];
        }
        return n-sum;
    }
    // n*(n+1)/2;

//    public int missingNumber(int[] nums) {
//        Arrays.sort(nums);
//        int i =0;
//        for (i=0;i<nums.length;i++)
//        {
//            if (nums[i]!=i) return i;
//        }
//        return i;
//    }
    public static void main(String[] args) {
        int[] nums = {3,0,1,4,5,6,7};
        System.out.println(new Q268().missingNumber(nums));
    }
}
