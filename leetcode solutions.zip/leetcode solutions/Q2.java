package com.company;

public class Q2 {
    public class ListNode {
      int val;
      ListNode next;
      ListNode() {}
      ListNode(int val) { this.val = val; }
      ListNode(int val, ListNode next) { this.val = val; this.next = next; }
  }


  public ListNode addTwoNumbers(ListNode l1, ListNode l2) {
    ListNode fake = new ListNode(0);
    ListNode p = fake;

    ListNode p1 = l1;
    ListNode p2 = l2;

    int carry = 0;
    while(p1!=null || p2!=null){
      int sum = carry;
      if(p1!=null){
        sum += p1.val;
        p1 = p1.next;
      }

      if(p2!=null){
        sum += p2.val;
        p2 = p2.next;
      }

      if(sum>9){
        carry=1;
        sum = sum-10;
      }else{
        carry = 0;
      }

      ListNode l = new ListNode(sum);
      p.next = l;
      p = p.next;
    }

    if(carry > 0){
      ListNode l = new ListNode(carry);
      p.next = l;
    }
    return fake.next;
  }

  public void traverse(ListNode head)
  {
    ListNode current = head;
    while (current!=null)
    {
      System.out.println(current.val);
      current = current.next;
    }
  }

    public static void main(String[] args) {
      Q2 q = new Q2();
      ListNode n1 = q.new ListNode(2);
      ListNode n2= q.new ListNode(4);
      ListNode n3 = q.new ListNode(3);
      ListNode n4= q.new ListNode(5);
      ListNode n5 = q.new ListNode(6);
      ListNode n6 = q.new ListNode(3);
//      ListNode n7= q.new ListNode(3);
//      ListNode n8 = q.new ListNode(1);

      ListNode head1 = n1;
      head1.next=n2;
      n2.next=n3;
      n3.next=null;

      ListNode head2 = n4;
      head2.next=n5;
      n5.next=n6;
      n6.next=null;
      ListNode newlist = q.addTwoNumbers(head1,head2);
      q.traverse(newlist);
    }

}
